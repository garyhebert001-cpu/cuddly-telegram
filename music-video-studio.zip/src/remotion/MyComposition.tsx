import React from 'react';
import { AbsoluteFill, Video, Sequence, interpolate, useCurrentFrame, useVideoConfig } from 'remotion';
import { TransitionSeries, linearTiming } from '@remotion/transitions';
import { fade } from '@remotion/transitions/fade';
import { slide } from '@remotion/transitions/slide';
import { wipe } from '@remotion/transitions/wipe';
import { flip } from '@remotion/transitions/flip';
import { zoomBlurPresentation, glitchPresentation, panBlurPresentation, spinBlurPresentation, elasticZoomPresentation, rgbSplitPresentation, stretchPresentation, bloomFlashPresentation, warpSpeedPresentation, vortexPresentation, liquidPresentation, slideUpPresentation, bouncePresentation, pixelatePresentation, swirlPresentation, crossZoomPresentation, cubePresentation, doomPresentation, directionalWipePresentation, radialWipePresentation, heartWipePresentation, starWipePresentation, angularWipePresentation, tvNoisePresentation, mosaicPresentation } from './AdvancedTransitions';

export interface TextOverlay {
  id: string;
  text: string;
  startFrame: number;
  durationInFrames: number;
  x: number;
  y: number;
  fontSize: number;
  color: string;
  fontFamily?: string;
  strokeColor?: string;
  strokeWidth?: number;
  shadowColor?: string;
  shadowBlur?: number;
  shadowOffset?: { x: number, y: number };
  animation?: string;
  backgroundColor?: string;
  backgroundOpacity?: number;
  borderRadius?: number;
  padding?: number;
  borderWidth?: number;
  borderColor?: string;
  glassEffect?: boolean;
  letterSpacing?: number;
  lineHeight?: number;
  textAlign?: 'left' | 'center' | 'right';
  vfxShader?: string;
  vfxUniforms?: Record<string, any>;
}

export interface VideoClip {
  id: string;
  src: string;
  durationInFrames: number;
  startFrom?: number;
  playbackRate?: number;
  volume?: number;
  brightness?: number;
  contrast?: number;
  saturation?: number;
  blur?: number;
  hueRotate?: number;
  invert?: number;
  transitionType?: 'none' | 'fade' | 'slide' | 'wipe' | 'flip' | 'zoomBlur' | 'glitch' | 'panBlur' | 'spinBlur' | 'elasticZoom' | 'rgbSplit' | 'stretch' | 'bloomFlash' | 'warpSpeed' | 'vortex' | 'liquid' | 'slideUp' | 'bounce' | 'pixelate' | 'swirl' | 'crossZoom' | 'cube' | 'doom' | 'directionalWipe' | 'radialWipe' | 'heartWipe' | 'starWipe' | 'angularWipe' | 'tvNoise' | 'mosaic';
  transitionDuration?: number;
  audioFadeIn?: number;
  audioFadeOut?: number;
  vfxShader?: string;
  vfxUniforms?: Record<string, any>;
}

const ClipVideo: React.FC<{ clip: VideoClip }> = ({ clip }) => {
  const frame = useCurrentFrame();
  const baseVolume = clip.volume ?? 1;
  const fadeIn = clip.audioFadeIn || 0;
  const fadeOut = clip.audioFadeOut || 0;
  const duration = clip.durationInFrames;

  const volume = interpolate(
    frame,
    [0, fadeIn, Math.max(fadeIn, duration - fadeOut), duration].map((v, i) => v + i * 0.0001),
    [0, baseVolume, baseVolume, 0],
    { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }
  );

  return (
    <Video 
      src={clip.src} 
      startFrom={clip.startFrom || 0}
      playbackRate={clip.playbackRate || 1}
      volume={volume}
      style={{ 
        width: '100%', 
        height: '100%', 
        objectFit: 'cover' 
      }} 
    />
  );
};

const LyricWord: React.FC<{ word: string, index: number, textColorTheme: string, highlightColorTheme: string, fontAnimation: string }> = ({ word, index, textColorTheme, highlightColorTheme, fontAnimation }) => {
  const isHighlight = word.toLowerCase().includes('bitch') || word.toLowerCase().includes('fuck') || word.toLowerCase().includes('pussy');
  
  return (
    <span
      className={`inline-block mr-[0.25em] ${isHighlight ? `liquid-glass-text-highlight ${highlightColorTheme}` : `liquid-glass-text ${textColorTheme}`} ${fontAnimation}`}
      style={{
        display: 'inline-block',
        marginRight: '0.25em'
      }}
    >
      {word}
    </span>
  );
};

export const MyComposition: React.FC<{ 
  clips: VideoClip[], 
  textOverlays?: TextOverlay[], 
  globalFilter?: string,
  liquidScale?: number,
  liquidFreq?: number,
  lyricsStyle?: {
    padding: number;
    borderRadius: number;
    backgroundColor: string;
    backgroundOpacity: number;
    vfxShader?: string;
    vfxUniforms?: any;
    glassFrost: number;
    glassBevel: number;
    glassRefraction: number;
    glassMagnification: number;
    x: number;
    y: number;
    width: number;
    height: number;
  },
  parsedLyrics?: { time: number; text: string }[],
  fontFamily?: string,
  textSize?: number,
  textColorTheme?: string,
  highlightColorTheme?: string,
  fontAnimation?: string,
  radiantOverlay?: string,
  radiantOpacity?: number
}> = ({ 
  clips, 
  textOverlays = [], 
  globalFilter = 'none', 
  liquidScale = 30, 
  liquidFreq = 0.01,
  lyricsStyle,
  parsedLyrics = [],
  fontFamily = 'font-sans',
  textSize = 4,
  textColorTheme = 'theme-white',
  highlightColorTheme = 'highlight-red',
  fontAnimation = 'anim-shine',
  radiantOverlay = 'none',
  radiantOpacity = 0.5
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const uTime = frame / fps;

  const currentLyricIndex = [...parsedLyrics].reverse().findIndex(l => l.time <= uTime);
  const actualLyricIndex = currentLyricIndex === -1 ? -1 : parsedLyrics.length - 1 - currentLyricIndex;

  if (!clips || clips.length === 0) {
    return (
      <AbsoluteFill style={{ backgroundColor: 'black', justifyContent: 'center', alignItems: 'center' }}>
        <span style={{ color: 'white' }}>No clips selected</span>
      </AbsoluteFill>
    );
  }

  const getFilterString = (clipOrFilter: VideoClip | string) => {
    let filterStr = '';
    let f = '';

    if (typeof clipOrFilter === 'string') {
      f = clipOrFilter;
    } else {
      filterStr = `brightness(${clipOrFilter.brightness || 1}) contrast(${clipOrFilter.contrast || 1}) saturate(${clipOrFilter.saturation || 1}) blur(${clipOrFilter.blur || 0}px) hue-rotate(${clipOrFilter.hueRotate || 0}deg) invert(${clipOrFilter.invert || 0})`;
      f = globalFilter || 'none';
    }
    
    if (f === 'grayscale') filterStr += ' grayscale(100%)';
    else if (f === 'sepia') filterStr += ' sepia(100%)';
    else if (f === 'invert') filterStr += ' invert(100%)';
    else if (f === 'hue-rotate-90') filterStr += ' hue-rotate(90deg)';
    else if (f === 'hue-rotate-180') filterStr += ' hue-rotate(180deg)';
    else if (f === 'blur-sm') filterStr += ' blur(4px)';
    else if (f === 'contrast-150 saturate-200') filterStr += ' contrast(1.5) saturate(2)';
    else if (f === 'filter-y2k') filterStr += ' contrast(1.5) saturate(1.5) brightness(1.2) hue-rotate(-10deg) sepia(0.2)';
    else if (f === 'filter-frutiger') filterStr += ' saturate(2) brightness(1.1) contrast(1.1)';
    else if (f === 'filter-metal') filterStr += ' grayscale(1) contrast(2) brightness(0.8) invert(0.1)';
    else if (f === 'filter-cyber') filterStr += ' hue-rotate(180deg) saturate(3) contrast(1.2) brightness(1.1)';
    else if (f === 'filter-dream') filterStr += ' blur(2px) saturate(1.5) brightness(1.2) contrast(0.9)';
    else if (f === 'radiant-1') filterStr += ' brightness(1.2) contrast(1.1) saturate(1.3)';
    else if (f === 'radiant-2') filterStr += ' hue-rotate(45deg) brightness(1.1)';
    else if (f === 'radiant-3') filterStr += ' sepia(0.3) brightness(1.2) contrast(1.1)';
    else if (f === 'radiant-4') filterStr += ' invert(0.2) sepia(0.2) saturate(1.5)';
    else if (f === 'radiant-5') filterStr += ' saturate(2) brightness(1.2)';
    else if (f === 'radiant-6') filterStr += ' contrast(1.5) brightness(0.9)';
    else if (f === 'radiant-7') filterStr += ' hue-rotate(270deg) saturate(2)';
    else if (f === 'radiant-8') filterStr += ' blur(1px) brightness(1.3)';
    else if (f === 'radiant-9') filterStr += ' sepia(0.5) hue-rotate(300deg)';
    else if (f === 'radiant-10') filterStr += ' contrast(1.2) brightness(1.1) saturate(1.5)';
    else if (f === 'filter-upscale') filterStr += ' contrast(1.1) brightness(1.05) saturate(1.05)';
    else if (f === 'filter-4k-upscale') filterStr += ' contrast(1.2) brightness(1.1) saturate(1.1)';
    else if (f === 'filter-liquid-gl') filterStr += ' url(#liquid-gl)';
    
    return filterStr;
  };

  const getTransition = (type: string) => {
    switch (type) {
      case 'fade': return fade();
      case 'slide': return slide();
      case 'wipe': return wipe();
      case 'flip': return flip();
      case 'zoomBlur': return zoomBlurPresentation();
      case 'glitch': return glitchPresentation();
      case 'panBlur': return panBlurPresentation();
      case 'spinBlur': return spinBlurPresentation();
      case 'elasticZoom': return elasticZoomPresentation();
      case 'rgbSplit': return rgbSplitPresentation();
      case 'stretch': return stretchPresentation();
      case 'bloomFlash': return bloomFlashPresentation();
      case 'warpSpeed': return warpSpeedPresentation();
      case 'vortex': return vortexPresentation();
      case 'liquid': return liquidPresentation();
      case 'slideUp': return slideUpPresentation();
      case 'bounce': return bouncePresentation();
      case 'pixelate': return pixelatePresentation();
      case 'swirl': return swirlPresentation();
      case 'crossZoom': return crossZoomPresentation();
      case 'cube': return cubePresentation();
      case 'doom': return doomPresentation();
      case 'directionalWipe': return directionalWipePresentation();
      case 'radialWipe': return radialWipePresentation();
      case 'heartWipe': return heartWipePresentation();
      case 'starWipe': return starWipePresentation();
      case 'angularWipe': return angularWipePresentation();
      case 'tvNoise': return tvNoisePresentation();
      case 'mosaic': return mosaicPresentation();
      default: return null;
    }
  };

  const background = (
    <TransitionSeries>
      {clips.flatMap((clip, index) => {
        const presentation = index < clips.length - 1 && clip.transitionType && clip.transitionType !== 'none'
          ? getTransition(clip.transitionType)
          : null;

        const sequence = (
          <TransitionSeries.Sequence key={`seq-${clip.id}`} durationInFrames={clip.durationInFrames}>
            <AbsoluteFill style={{ justifyContent: 'center', alignItems: 'center' }}>
              <div style={{ 
                width: '100%',
                height: '100%',
                filter: getFilterString(clip)
              }}>
                <ClipVideo clip={clip} />
              </div>
            </AbsoluteFill>
          </TransitionSeries.Sequence>
        );

        if (presentation) {
          return [
            sequence,
            <TransitionSeries.Transition
              key={`trans-${clip.id}`}
              presentation={presentation as any}
              timing={linearTiming({ durationInFrames: clip.transitionDuration || 15 })}
            />
          ];
        }
        return [sequence];
      })}
    </TransitionSeries>
  );

  const lyricsLayer = (
    <AbsoluteFill style={{ pointerEvents: 'none' }}>
      {lyricsStyle && actualLyricIndex >= 0 && parsedLyrics[actualLyricIndex]?.text && (
        <AbsoluteFill style={{
          left: `${lyricsStyle.x}%`,
          top: `${lyricsStyle.y}%`,
          width: `${lyricsStyle.width}%`,
          height: `${lyricsStyle.height}%`,
          padding: lyricsStyle.padding,
          borderRadius: lyricsStyle.borderRadius,
          backgroundColor: `${lyricsStyle.backgroundColor}${Math.round(lyricsStyle.backgroundOpacity * 255).toString(16).padStart(2, '0')}`,
          backdropFilter: `blur(${lyricsStyle.glassFrost}px) contrast(1.4) saturate(1.4) brightness(1.1)`,
          WebkitBackdropFilter: `blur(${lyricsStyle.glassFrost}px) contrast(1.4) saturate(1.4) brightness(1.1)`,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          textAlign: 'center',
          overflow: 'hidden',
          boxShadow: `
            inset 0 0 ${lyricsStyle.glassBevel * 200}px rgba(255,255,255,${0.1 + lyricsStyle.glassBevel}),
            0 ${20 + lyricsStyle.glassBevel * 100}px ${50 + lyricsStyle.glassBevel * 100}px rgba(0,0,0,0.5),
            inset ${lyricsStyle.glassBevel * 10}px ${lyricsStyle.glassBevel * 10}px ${lyricsStyle.glassBevel * 20}px rgba(255,255,255,0.4),
            inset -${lyricsStyle.glassBevel * 10}px -${lyricsStyle.glassBevel * 10}px ${lyricsStyle.glassBevel * 20}px rgba(0,0,0,0.3)
          `,
          border: `${1 + lyricsStyle.glassBevel * 5}px solid rgba(255,255,255,${0.2 + lyricsStyle.glassBevel})`,
          borderTop: `${2 + lyricsStyle.glassBevel * 10}px solid rgba(255,255,255,${0.4 + lyricsStyle.glassBevel})`,
          borderLeft: `${2 + lyricsStyle.glassBevel * 10}px solid rgba(255,255,255,${0.3 + lyricsStyle.glassBevel})`,
          transform: `perspective(1000px) rotateX(${lyricsStyle.glassBevel * 5}deg)`,
        }}>
          <div style={{
            position: 'absolute',
            inset: 0,
            background: 'linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 50%, rgba(0,0,0,0.1) 100%)',
            pointerEvents: 'none'
          }} />
          <div className="text-center w-full">
            <h2 
              className={`${fontFamily} uppercase flex flex-wrap justify-center leading-[0.85]`}
              style={{ fontSize: `${textSize}rem`, textShadow: '0 10px 30px rgba(0,0,0,0.5)' }}
            >
              {parsedLyrics[actualLyricIndex].text.split(' ').map((word, i) => (
                <LyricWord key={`${actualLyricIndex}-${i}`} word={word} index={i} textColorTheme={textColorTheme} highlightColorTheme={highlightColorTheme} fontAnimation={fontAnimation} />
              ))}
            </h2>
          </div>
        </AbsoluteFill>
      )}
    </AbsoluteFill>
  );

  const overlaysLayer = (
    <AbsoluteFill style={{ pointerEvents: 'none' }}>
      {textOverlays.map((overlay) => (
        <Sequence
          key={overlay.id}
          from={overlay.startFrame}
          durationInFrames={overlay.durationInFrames}
        >
          <div
            className={`${overlay.animation && overlay.animation !== 'none' ? `anim-${overlay.animation}` : ''} ${overlay.glassEffect ? 'text-box-glass' : ''}`}
            style={{
              position: 'absolute',
              left: `${overlay.x}%`,
              top: `${overlay.y}%`,
              fontSize: `${overlay.fontSize}px`,
              color: overlay.color,
              fontFamily: overlay.fontFamily || 'sans-serif',
              transform: 'translate(-50%, -50%)',
              textShadow: overlay.shadowColor 
                ? `${overlay.shadowOffset?.x || 0}px ${overlay.shadowOffset?.y || 2}px ${overlay.shadowBlur || 4}px ${overlay.shadowColor}`
                : '0 2px 4px rgba(0,0,0,0.5)',
              WebkitTextStroke: overlay.strokeWidth 
                ? `${overlay.strokeWidth}px ${overlay.strokeColor || '#000'}`
                : undefined,
              backgroundColor: overlay.backgroundColor 
                ? `rgba(${parseInt(overlay.backgroundColor.slice(1,3), 16)}, ${parseInt(overlay.backgroundColor.slice(3,5), 16)}, ${parseInt(overlay.backgroundColor.slice(5,7), 16)}, ${overlay.backgroundOpacity || 0.5})`
                : undefined,
              borderRadius: `${overlay.borderRadius || 0}px`,
              padding: `${overlay.padding || 0}px`,
              border: overlay.borderWidth ? `${overlay.borderWidth}px solid ${overlay.borderColor || 'white'}` : undefined,
              letterSpacing: `${overlay.letterSpacing || 0}px`,
              lineHeight: overlay.lineHeight || 1.2,
              textAlign: overlay.textAlign || 'center',
              whiteSpace: 'pre-wrap',
              maxWidth: '80%',
              filter: overlay.vfxShader ? getFilterString(overlay.vfxShader) : undefined,
            }}
          >
            {overlay.text}
          </div>
        </Sequence>
      ))}
    </AbsoluteFill>
  );

  // Final assembly
  const finalContent = (
    <AbsoluteFill style={{ backgroundColor: 'black' }}>
      {/* Background Layer */}
      <AbsoluteFill style={{ filter: getFilterString(globalFilter || 'none') }}>
        {background}
      </AbsoluteFill>
      
      {/* Glass Layer (if active) */}
      {lyricsStyle?.vfxShader === 'liquidGL' && (
        <div
          style={{
            position: 'absolute',
            left: `${lyricsStyle.x}%`,
            top: `${lyricsStyle.y}%`,
            width: `${lyricsStyle.width}%`,
            height: `${lyricsStyle.height}%`,
            backdropFilter: `blur(${lyricsStyle.glassFrost * 20}px) saturate(1.5) brightness(1.1)`,
            borderRadius: `${lyricsStyle.borderRadius}px`,
            border: `${lyricsStyle.glassBevel}px solid rgba(255, 255, 255, 0.2)`,
            boxShadow: `
              inset 0 0 ${lyricsStyle.glassBevel * 2}px rgba(255, 255, 255, 0.3),
              0 10px 30px rgba(0, 0, 0, 0.3)
            `,
            overflow: 'hidden',
            zIndex: 10,
            transform: `scale(${1 + lyricsStyle.glassMagnification * 0.1})`,
            pointerEvents: 'none'
          }}
        />
      )}

      {/* Lyrics Layer */}
      {lyricsLayer}

      {/* Overlays Layer */}
      {overlaysLayer}

      {/* Radiant Overlay Layer */}
      {radiantOverlay !== 'none' && (
        <AbsoluteFill 
          style={{ 
            opacity: radiantOpacity,
            pointerEvents: 'none',
            background: radiantOverlay === 'radiant-1' ? 'linear-gradient(45deg, rgba(255,0,0,0.2), rgba(0,0,255,0.2))' :
                        radiantOverlay === 'radiant-2' ? 'linear-gradient(135deg, rgba(0,255,0,0.2), rgba(255,255,0,0.2))' :
                        radiantOverlay === 'radiant-3' ? 'radial-gradient(circle, rgba(255,255,255,0.2) 0%, transparent 70%)' :
                        radiantOverlay === 'radiant-4' ? 'linear-gradient(to right, rgba(255,0,255,0.1), rgba(0,255,255,0.1))' :
                        radiantOverlay === 'radiant-5' ? 'linear-gradient(to bottom, rgba(255,255,0,0.1), rgba(255,0,0,0.1))' :
                        'transparent'
          }}
        />
      )}
    </AbsoluteFill>
  );

  return finalContent;
};
